import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, ShoppingCart, Truck, Shield, Headphones, Zap, Snowflake, Utensils } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

const featuredProducts = [
  {
    id: 1,
    name: "LG 24,000 BTU Smart Air Conditioner",
    price: 1299.99,
    originalPrice: 1599.99,
    image: "/placeholder.svg?height=300&width=300&text=Air+Conditioner",
    rating: 4.8,
    reviews: 324,
    badge: "Energy Star",
    energyRating: "A+++",
  },
  {
    id: 2,
    name: 'Samsung 24" Built-in Dishwasher',
    price: 899.99,
    originalPrice: 1199.99,
    image: "/placeholder.svg?height=300&width=300&text=Dishwasher",
    rating: 4.6,
    reviews: 189,
    badge: "Best Seller",
    energyRating: "A++",
  },
  {
    id: 3,
    name: "Whirlpool French Door Refrigerator",
    price: 2199.99,
    originalPrice: 2599.99,
    image: "/placeholder.svg?height=300&width=300&text=Refrigerator",
    rating: 4.9,
    reviews: 256,
    badge: "New Model",
    energyRating: "A+++",
  },
  {
    id: 4,
    name: "Bosch Front Load Washing Machine",
    price: 1499.99,
    originalPrice: 1799.99,
    image: "/placeholder.svg?height=300&width=300&text=Washing+Machine",
    rating: 4.7,
    reviews: 403,
    badge: "Popular",
    energyRating: "A++",
  },
]

const categories = [
  {
    name: "Air Conditioners",
    image: "/placeholder.svg?height=200&width=200&text=AC+Unit",
    count: "45+ models",
    icon: <Snowflake className="h-8 w-8" />,
  },
  {
    name: "Kitchen Appliances",
    image: "/placeholder.svg?height=200&width=200&text=Kitchen",
    count: "120+ items",
    icon: <Utensils className="h-8 w-8" />,
  },
  {
    name: "Laundry",
    image: "/placeholder.svg?height=200&width=200&text=Laundry",
    count: "35+ models",
    icon: <Zap className="h-8 w-8" />,
  },
  {
    name: "Refrigeration",
    image: "/placeholder.svg?height=200&width=200&text=Fridge",
    count: "67+ models",
    icon: <Snowflake className="h-8 w-8" />,
  },
]

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-900 to-indigo-800 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl font-bold mb-6">Premium Home Appliances & Electronics</h1>
              <p className="text-xl mb-8 text-blue-100">
                Discover energy-efficient appliances from top brands. Free delivery and professional installation
                available.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Button size="lg" className="bg-white text-blue-900 hover:bg-gray-100">
                  Shop Appliances
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-blue-900 bg-transparent"
                >
                  View Brands
                </Button>
              </div>
              <div className="flex items-center gap-6 text-sm">
                <div className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  <span>5-Year Warranty</span>
                </div>
                <div className="flex items-center gap-2">
                  <Truck className="h-5 w-5" />
                  <span>Free Installation</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=400&width=500&text=Modern+Kitchen"
                alt="Modern Kitchen Appliances"
                width={500}
                height={400}
                className="rounded-lg shadow-2xl"
              />
              <div className="absolute -bottom-4 -left-4 bg-green-500 text-white px-4 py-2 rounded-lg font-semibold">
                Energy Star Certified
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Truck className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Free Delivery & Installation</h3>
              <p className="text-gray-600">Professional installation included on major appliances</p>
            </div>
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Extended Warranty</h3>
              <p className="text-gray-600">Up to 5-year warranty on all major appliances</p>
            </div>
            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Headphones className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Expert Support</h3>
              <p className="text-gray-600">Technical support and maintenance services</p>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Shop by Category</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category, index) => (
              <Link key={index} href={`/category/${category.name.toLowerCase().replace(" ", "-")}`}>
                <Card className="hover:shadow-lg transition-shadow cursor-pointer group">
                  <CardContent className="p-6 text-center">
                    <div className="mb-4 text-blue-600 group-hover:text-blue-700 transition-colors">
                      {category.icon}
                    </div>
                    <Image
                      src={category.image || "/placeholder.svg"}
                      alt={category.name}
                      width={200}
                      height={150}
                      className="mx-auto mb-4 rounded-lg"
                    />
                    <h3 className="text-xl font-semibold mb-2">{category.name}</h3>
                    <p className="text-gray-600">{category.count}</p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-12">
            <h2 className="text-3xl font-bold">Featured Appliances</h2>
            <Link href="/products">
              <Button variant="outline">View All Products</Button>
            </Link>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <Card key={product.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-0">
                  <div className="relative">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      width={300}
                      height={300}
                      className="w-full h-64 object-cover rounded-t-lg"
                    />
                    <Badge className="absolute top-2 left-2" variant="secondary">
                      {product.badge}
                    </Badge>
                    <Badge className="absolute top-2 right-2 bg-green-600">{product.energyRating}</Badge>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold mb-2 line-clamp-2">{product.name}</h3>
                    <div className="flex items-center mb-2">
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${
                              i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-gray-600 ml-2">({product.reviews})</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-lg font-bold">${product.price}</span>
                        <span className="text-sm text-gray-500 line-through ml-2">${product.originalPrice}</span>
                      </div>
                      <Button size="sm">
                        <ShoppingCart className="h-4 w-4 mr-2" />
                        Add to Cart
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Brands Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Trusted Brands</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 items-center">
            {["LG", "Samsung", "Whirlpool", "Bosch", "GE", "Frigidaire"].map((brand) => (
              <div key={brand} className="text-center">
                <Image
                  src={`/placeholder.svg?height=80&width=120&text=${brand}`}
                  alt={brand}
                  width={120}
                  height={80}
                  className="mx-auto grayscale hover:grayscale-0 transition-all opacity-60 hover:opacity-100"
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 bg-blue-900 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Stay Updated on Latest Appliances</h2>
          <p className="text-xl mb-8 text-blue-100">
            Get exclusive deals, energy-saving tips, and new product announcements
          </p>
          <div className="max-w-md mx-auto flex gap-4">
            <input type="email" placeholder="Enter your email" className="flex-1 px-4 py-2 rounded-lg text-black" />
            <Button className="bg-white text-blue-900 hover:bg-gray-100">Subscribe</Button>
          </div>
        </div>
      </section>
    </div>
  )
}
